-module(bapelsin_test_helper).

-export([foo/0]).


foo() ->
    ok.
