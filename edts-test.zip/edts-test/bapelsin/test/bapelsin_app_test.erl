-module(bapelsin_app_test).

-include_lib("eunit/include/eunit.hrl").

bapelsin_test() ->
    bapelsin_test_helper:foo().
